/* ============================================================
   WideCast — CINEMA variant · app.js (vanilla)
   nav scroll state · mobile menu · tab switching (install + code)
   copy-to-clipboard · scroll reveal · letterbox reveal
   agent-transcript reveal · filmstrip playhead + marquee light-up
   inert placeholder links
   ============================================================ */
(function () {
  "use strict";

  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- letterbox reveal on load ---------- */
  document.documentElement.classList.add("letterbox-loading");
  window.addEventListener("load", function () {
    // small delay so the closed bars are seen, then open
    setTimeout(function () {
      document.documentElement.classList.remove("letterbox-loading");
    }, reduceMotion ? 0 : 240);
  });

  /* ---------- nav scroll state ---------- */
  var nav = document.getElementById("nav");
  function onScroll() {
    if (window.scrollY > 24) nav.classList.add("scrolled");
    else nav.classList.remove("scrolled");
  }
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  /* ---------- mobile menu ---------- */
  var toggle = document.getElementById("navToggle");
  var navLinks = document.getElementById("navLinks");
  if (toggle) {
    toggle.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
    });
    navLinks.addEventListener("click", function (e) {
      if (e.target.tagName === "A") {
        nav.classList.remove("open");
        toggle.setAttribute("aria-expanded", "false");
      }
    });
  }

  /* ---------- generic tab switching ---------- */
  function wireTabs(tabSel, tabAttr, paneSel, paneAttr) {
    var tabs = document.querySelectorAll(tabSel);
    tabs.forEach(function (tab) {
      tab.addEventListener("click", function () {
        var key = tab.getAttribute(tabAttr);
        // tabs
        tabs.forEach(function (t) {
          var active = t === tab;
          t.classList.toggle("is-active", active);
          if (t.hasAttribute("role")) t.setAttribute("aria-selected", active ? "true" : "false");
        });
        // panes
        document.querySelectorAll(paneSel).forEach(function (p) {
          p.classList.toggle("is-active", p.getAttribute(paneAttr) === key);
        });
      });
    });
  }
  wireTabs(".install-tab", "data-install", ".install-cmd[data-install-body]", "data-install-body");
  wireTabs(".code-tab", "data-code", ".code-pane", "data-code-body");

  /* ---------- copy to clipboard ---------- */
  document.querySelectorAll(".copy-btn").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var sel = btn.getAttribute("data-copy-target");
      var el = document.querySelector(sel);
      if (!el) return;
      var text = el.textContent.trim();
      var done = function () {
        var prev = btn.textContent;
        btn.textContent = "Copied";
        btn.classList.add("copied");
        setTimeout(function () {
          btn.textContent = prev;
          btn.classList.remove("copied");
        }, 1400);
      };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(done, fallbackCopy);
      } else {
        fallbackCopy();
      }
      function fallbackCopy() {
        var ta = document.createElement("textarea");
        ta.value = text;
        ta.style.position = "fixed";
        ta.style.opacity = "0";
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand("copy"); done(); } catch (e) {}
        document.body.removeChild(ta);
      }
    });
  });

  /* ---------- inert placeholder links ---------- */
  document.querySelectorAll(".js-inert").forEach(function (el) {
    el.addEventListener("click", function (e) {
      // allow real in-page anchors (start with #section that exists)
      var href = el.getAttribute("href") || "";
      var target = href.length > 1 ? document.querySelector(href) : null;
      if (target && !el.hasAttribute("data-inert-force")) return;
      e.preventDefault();
    });
  });

  /* ---------- scroll reveal ---------- */
  var revealEls = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) {
          en.target.classList.add("in");
          io.unobserve(en.target);
          // kick the transcript when the hero stage reveals
          if (en.target.id === "hero-reel") playTranscript();
        }
      });
    }, { threshold: 0.16, rootMargin: "0px 0px -8% 0px" });
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add("in"); });
    playTranscript();
  }

  /* ---------- agent transcript reveal ---------- */
  var transcriptPlayed = false;
  function playTranscript() {
    if (transcriptPlayed) return;
    transcriptPlayed = true;
    var lines = document.querySelectorAll("#transcript .t-line");
    if (reduceMotion) {
      lines.forEach(function (l) { l.classList.add("show"); });
      return;
    }
    lines.forEach(function (line, i) {
      setTimeout(function () { line.classList.add("show"); }, 350 + i * 520);
    });
  }

  /* ---------- filmstrip playhead + marquee light-up ---------- */
  var strip = document.getElementById("filmstrip");
  var playhead = document.getElementById("playhead");
  var stages = strip ? strip.querySelectorAll(".strip-stage") : [];
  var lights = document.querySelectorAll("#marqueeLights li");
  var marqueeRunning = false;

  function lightStage(idx) {
    stages.forEach(function (s, i) {
      s.classList.toggle("lit", i <= idx);
    });
  }

  function runMarquee() {
    // sequentially light the 10 platform bulbs
    lights.forEach(function (li, i) {
      setTimeout(function () { li.classList.add("on"); }, i * 130);
    });
  }

  function runPlayhead() {
    if (!strip || !playhead) return;
    if (reduceMotion) {
      playhead.style.display = "none";
      lightStage(stages.length - 1);
      lights.forEach(function (li) { li.classList.add("on"); });
      return;
    }
    var start = null;
    var duration = 4200; // ms across the strip
    var fromPct = 4, toPct = 96;
    function frame(ts) {
      if (start === null) start = ts;
      var t = Math.min((ts - start) / duration, 1);
      var pct = fromPct + (toPct - fromPct) * t;
      playhead.style.left = pct + "%";
      // light stages as the head passes their boundaries (4 stages → quarters)
      var stageIdx = Math.min(Math.floor(t * stages.length), stages.length - 1);
      lightStage(stageIdx);
      if (t >= 1) {
        if (!marqueeRunning) { marqueeRunning = true; runMarquee(); }
        return;
      }
      requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }

  /* ---------- teleprompter delivery-mode toggle ---------- */
  var modeToggle = document.getElementById("modeToggle");
  if (modeToggle) {
    var modeBtns = modeToggle.querySelectorAll(".mode-btn");
    modeBtns.forEach(function (btn) {
      btn.addEventListener("click", function () {
        modeBtns.forEach(function (b) {
          var active = b === btn;
          b.classList.toggle("is-active", active);
          if (b.hasAttribute("role")) b.setAttribute("aria-selected", active ? "true" : "false");
        });
      });
    });
  }

  // start the playhead once the filmstrip is on screen
  if (strip && "IntersectionObserver" in window) {
    var stripIO = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) {
          runPlayhead();
          stripIO.unobserve(en.target);
        }
      });
    }, { threshold: 0.4 });
    stripIO.observe(strip);
  } else {
    runPlayhead();
  }
})();
