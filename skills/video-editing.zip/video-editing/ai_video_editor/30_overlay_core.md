# 30 · Overlay core — author ANY overlay as SVG (model, threshold, standard, reuse-photo, apply & verify)

_Version: `modular-1.1` · module of the AI Video Editor Playbook (`SKILL.md`)._

> **Module of the AI Video Editor Playbook.** Master index + checklist + critical rules live in `SKILL.md`. **Load this when:** you are going to (re)build or apply ANY overlay. ALWAYS load this first; if the overlay contains any text/title/label/value, load `31_typography.md` too even when the main pattern is a chart/diagram; then load the per-content style guide (`32_charts.md` for charts/diagrams, `33_patterns.md` for the rest).
> Cross-refs: text look→`31_typography.md`+`styles/text_axes.md`; chart/diagram→`32_charts.md`+`styles/chart_axes.md`; other patterns→`33_patterns.md`.

---

> **⭐ LOAD CHAIN — this file is step 1 of TWO–FOUR for any overlay. Before you author, you MUST also `Read`:**
> - **`10_mechanics.md` when `show_narrator=true` / `active_roll="A"`** — A-roll overlay authoring must run the full-canvas-first priority ladder in Gate 4 before the agent accepts, rebuilds, uploads, or layout-fixes the overlay. This is where the narrator/overlay tradeoff is designed; Gate 6 only verifies.
> - **`40_thumbnail_cta.md` when this overlay belongs to the first real scene/opening poster, the immediate thumbnail sync, or the last content/CTA scene.** Endpoint scenes have poster/CTA standards that override normal pattern instincts: choose a named endpoint style and avoid generic centered cards, horizontal text bars, and plain title/subtitle panels.
> - **`31_typography.md` whenever the overlay contains ANY text/title/label/value** (almost every overlay, including charts/diagrams). This is the hero/title/readability standard; skipping it is how dark/muddy/tiny text slips through.
> - the **content module** for the scene's pattern — `31_typography.md` (text-led) · `32_charts.md` (`single_metric`/`bar_chart`/`proportion_chart`/`trend_chart`/`structural_diagram`) · `33_patterns.md` (everything else), **AND**
> - that module's **style recipe lib** — `styles/text_axes.md` or `styles/chart_axes.md` (the diverse looks live ONLY there).
>
> **Load checklist before you draw:** ☐ `30_overlay_core.md` (this) ☐ `10_mechanics.md` if A-roll ☐ `40_thumbnail_cta.md` if endpoint scene ☐ `31_typography.md` if any text appears ☐ matching content module `31`/`32`/`33` ☐ its `styles/*.md`. Stopping at this file = flat / off-pattern output. Skipping the A-roll ladder before drawing on narrator scenes = wrong narrator/overlay tradeoff. Skipping typography on a chart/diagram with labels = unreadable overlay risk. (Opening a module = a required ACTION, not optional — same rule as the master index.)
>
> **⭐ MODULE LOAD PROOF — hard gate before SVG authoring.** Before you write a new SVG or rebuild an existing overlay, print the master template:
> ```text
> Gate 4 MODULE LOAD PROOF:
> ☑ 30_overlay_core.md — SVG/object/upload rules
> ☑ 10_mechanics.md — A-roll layout priority ladder (required when `show_narrator=true`)
> ☑ 40_thumbnail_cta.md — endpoint scene rules (required only for scene 2/opening poster, thumbnail sync, or final CTA)
> ☑ 31_typography.md — title/label/readability rules (required because overlay has text)
> ☑ <31_typography.md | 32_charts.md | 33_patterns.md> — content module for pattern=<pattern>
> ☑ `styles/text_axes.md` or `styles/chart_axes.md` — style recipe library
> Decision: <leave existing overlay | rebuild SVG | layout-only fix>
> ```
> If a required line is missing, **STOP**. Load the missing module first. Do not draw, upload, or mark Gate 4 PASS until the proof is complete and visible in the chat/log.
> 
> **⭐ A-ROLL LAYOUT PRIORITY PROOF — hard Gate 4 gate before overlay decision/authoring/upload.** If `show_narrator=true`, print this before deciding to leave, rebuild, upload, apply, or layout-fix the overlay:
> ```text
> Gate 4 A-ROLL LAYOUT PRIORITY PROOF:
> ☑ 10_mechanics.md — opened for the A-roll priority ladder before overlay decision
> Scene class: <normal | special_endpoint_or_trust>
> Narrator role: <primary | secondary>
> Overlay role: <support | main_subject>
> Current layout read: <full-canvas | shifted-full-canvas | shrunken/fallback | other>
> Full-canvas gate: <PASS|FAIL> — tested narrator full canvas first with overlay above head or over chest; face clear, no dead zones, readable, caption clear
> Priority 2 check: <PASS|FAIL|N/A> — pull narrator down + overlay above head; reason if rejected
> Priority 3 check: <PASS|FAIL|N/A> — push narrator up + overlay over chest; reason if rejected
> Priority 4 fallback check: <PASS|FAIL|N/A> — allowed only after 1–3 fail; narrator as large as possible, face large/clear/in safe_rect, X inside canvas, Y overflow allowed if it improves face size
> Chosen priority: <1 | 2 | 3 | 4>
> Overlay plan: <leave existing | rebuild SVG | layout-only fix | disable overlay> with placement rationale
> Verdict: <PASS to continue Gate 4 | BLOCKED — revise overlay/narrator plan>
> ```
> If this is A-roll and this proof is missing, **STOP**. A fallback/shrunken narrator layout is never approved from its current state alone; the proof must show full-canvas and shifted-full-canvas options were tested first and failed with concrete reasons.
>
> **⭐ TITLE GATE PROOF — hard gate after draft, before upload.** Loading `31_typography.md` is not enough. If the SVG/overlay has a title or hero text, print this proof and revise on any FAIL:
> ```text
> Gate 4 TITLE GATE PROOF:
> Title copy: "<exact title text>"
> Takeaway source: <quote/talking_point words it encodes>
> Copy correctness check: <PASS|FAIL> — no typo/grammar/diacritic/casing/number/symbol/proper-noun/domain-term error; phrasing is natural for the scene language
> Semantic check: <PASS|FAIL> — states the scene takeaway, not just a panel label
> Hierarchy check: <PASS|FAIL> — title is stronger than badges/panel labels
> Thickness check: <PASS|FAIL> — body is thick via Black/Heavy font or approved offset-face recipe; outline is thin/controlled, not over-stroked
> Local SVG check: <PASS|FAIL> — saved local SVG was shown before upload and appears title-led
> Verdict: <PASS to upload | REVISE title before upload>
> ```
> Any FAIL blocks upload. Fix the SVG/title, show the revised local SVG, and repeat the gate. After upload, the saved/shown composite screenshot must still pass the final title check before Gate 4/6 can PASS:
> ```text
> Gate 6 TITLE SCREENSHOT CHECK:
> Composite screenshot shown: <yes|no>
> Screenshot check: <PASS|FAIL> — title matches the approved copy, has no visible typo/grammar/diacritic error, and is readable, prominent, thick-bodied, thin-outlined/not over-stroked, and stronger than labels
> Verdict: <PASS title | REVISE title/rebuild overlay>
> ```
>
> **⭐ SECONDARY TEXT/LABEL GATE — separate from title.** Title readability and label readability are two different gates. A title can PASS while the card text, chart labels, values, badges, or callouts FAIL. For every non-title text/value/label/card line, print and pass this before upload:
> ```text
> Gate 4 SECONDARY TEXT GATE PROOF:
> Text inventory: <exact non-title strings: values, labels, card text, badge text, callouts>
> Copy correctness check: <PASS|FAIL> — every string is typo-free, grammar-correct, domain-correct, and preserves required numbers/currency/%/proper nouns/diacritics
> Size floor check: <PASS|FAIL> — each non-title text is >= ~30px on the 720 canvas OR deliberately simplified/removed; nothing depends on zoom
> Contrast check: <PASS|FAIL> — each line uses solid high-contrast fill on a clean chip/card/quiet area; secondary text has NO visible stroke/outline; no dark-on-dark card text
> Container/padding check: <PASS|FAIL> — every line fits inside its card/chip/bar area with generous interior padding; no clipped/overflowing words; no text touches, grazes, or visually crosses a border
> Collision/Z-order check: <PASS|FAIL> — labels/values/badges do not overlap or cover each other; badges never sit on top of value labels unless both remain readable
> Local SVG check: <PASS|FAIL> — saved local SVG was shown before upload and all secondary text appears readable
> Verdict: <PASS to upload | REVISE labels before upload>
> ```
> After upload/layout tuning, the final composite screenshot must pass:
> ```text
> Gate 6 SECONDARY TEXT SCREENSHOT CHECK:
> Composite screenshot shown: <yes|no>
> Screenshot check: <PASS|FAIL> — every secondary label/value/card line matches the approved copy, has no visible typo/grammar/diacritic/domain error, is readable at 280×498 without zoom, has no visible outline/stroke, is not dark/muddy, is not overlapped/covered by another text/object, and has visible breathing room from its chip/card/bar border
> Verdict: <PASS secondary text | REVISE labels/layout/rebuild overlay>
> ```

### 0.5. How an uploaded overlay becomes objects (the SVG model)

You author the overlay as a **transparent SVG** (§5); `upload_overlay` sends the `.svg` and the server (`svg2spec`) turns it into the Remotion spec. The model is explicit — **no chroma key, no flat background color, no decompose guesswork**:

> **⭐ ONE GROUP = ONE OBJECT.** Every `<g data-wc-object="id">` in the SVG becomes exactly **one** Remotion object: the server renders that group alone on transparency, crops to its alpha bbox, and places it at that exact position (viewBox = the 720×1280 canvas, so the spec reproduces the SVG pixel-for-pixel). A nested *unmarked* `<g>` inside is just visual grouping; a marked group is atomic (not split further).
>
> **⭐ GROUPING IS THE ANIMATION UNIT.** Everything inside one group animates together (one beat); separate groups animate independently. To give a piece its own entry animation, put it in its own `data-wc-object` group — there is **no spacing/merge math** (that was the old raster-decompose model). Per-group entry comes from `data-wc-anim` (bar → growRight/growUp, text → a text-friendly entry, else the mapped hint or `fade`).
>
> **⭐ MAXIMAL GRANULARITY — one atom per object; atomize, NEVER clump.** Push the split as fine as it goes. The title is one object, and **every repeated element gets its OWN object**: a 4-item list is **4+ objects, one per item — NOT a title object plus one object holding all four**. Go finer *inside* an item too — a **check / bullet / number badge is its own object, SEPARATE from the text beside it**; a **bar is separate from its value label**; a **card frame is separate from its contents**; **each axis, connector, pin, legend row** is its own object. Rule of thumb: **if two marks could ever appear, animate, move, or sound at different times, they are TWO objects.** Only fuse marks that form one indivisible glyph. Granularity is free (each is just another `<g data-wc-object>`) and it BUYS per-element reveal, stagger, SFX, and individual editability/movability; clumping throws all of that away — one reveal for the whole clump, no per-item sound, not separately editable. To make several atoms still *appear together*, give them the **same `data-wc-delay`** (or one `data-wc-seq` wrapper) — they stay separate objects sharing a beat; **do NOT merge them into one group just to sync timing.**
>
> **⭐ TRANSPARENT, NOT CHROMA.** The SVG background is real transparency — **never paint a full-canvas background rect** (it would hide the scene video). Colors are free (no "background far from objects" rule). The scene video shows through wherever the SVG is transparent.

---

## 5. Create Overlay → SVG → Remotion Spec

> **An overlay is built ONE way: you author an SVG, upload it, and the server turns it into the Remotion spec.** You do not create raster overlay files, you do not write HTML, and you do not rasterize for upload/final QA or preview — you emit **SVG text**, show the local `.svg`, and `upload_overlay` it. WideCast's `svg2spec` converts each marked group into a spec object (transparent PNG + exact position + animation), renders the text with the project's fonts, and bakes the poster. **Assume you cannot generate images** — SVG is your full toolbox for text, numbers, diagrams, charts, callouts, icons, and vector illustration. (A realistic photo you cannot draw is never *created*; it is *reused* — §5.4.)

> **AESTHETICS ARE MANDATORY — push them as far as you can (this is a video).** Beautiful, tasteful, on-vibe — never a soulless plain box or bare dangling text. Invest in hierarchy (size / weight / color), a disciplined palette (**ONE derived accent**), rhythmic spacing, clean icons drawn as SVG shapes, and **match the topic's vibe** (warning→serious/red, finance→solid/green, tech→cyan-steel, fun→bright). Follow the `frontend-design` skill (anti-slop: no em-dash, no AI-purple, no three-generic-cards). **Readability is part of aesthetics, but readability alone is not enough:** hero/title text must be bright, high-contrast, instantly legible, and not squeezed against the canvas edge; secondary labels must still read without zoom, must not overlap other labels/badges, must not use visible stroke/outline, and must sit inside their chips/cards/bars with visible breathing room. Any text that touches, grazes, clips, or visually crosses a border is an aesthetic FAIL even when the letters are technically readable. Dark/muddy/thin/blurred/cramped text is a defect, not a style. Three hard rules frame every design:
> 1. **Canvas 720×1280, NO background — fully transparent.** The scene video shows through; there is **no chroma, no flat key color, no background rect**. The server reads the SVG's real transparency.
> 2. **Each thing that should animate on its own = its own `<g data-wc-object>` group** (§5.1).
> 3. **≥5% outer padding on all four canvas sides** — nothing touches the scene edge (content box **x ∈ [36, 684], y ∈ [128, 960]**). This is only the OUTER margin; text inside cards/chips/bars also needs its own INNER padding.
>
> **⭐ TEXT-CONTAINER PADDING RULE — high aesthetic gate.** A bordered chip/card/pill is **optional**, not mandatory. Decide internally: can the label/value sit cleanly as open text on a quiet area, inside the chart panel, or on a subtle no-border backplate? Use a bordered container only when it clearly improves contrast or grouping. If you do place text inside a chip, card, badge, bar, pill, table cell, or panel, it must have visible interior padding on all sides. Minimum target on the 720×1280 SVG canvas: **24–32px horizontal padding** and **14–20px vertical padding** around the rendered text bbox; for hero pills/cards, use more. In the 280×498 screenshot this should still look like real air, not a hairline gap. If a word touches/grazes the border, sits on a stroke, gets clipped by rounded corners, or looks crowded even though readable, Gate 4/6 FAILS. Fix by removing the unnecessary border/container, widening the container, shortening/splitting the label, reducing only secondary font size slightly while staying above the mobile floor, moving objects, or rebuilding the SVG. Do not approve "readable but cramped."

### 5.0. WHEN to (re)build an overlay — the threshold (method is always SVG)

Before touching a scene's overlay, decide WHETHER to rebuild — don't default to "regenerate".

> **⭐ OVERLAY COPY CORRECTNESS GATE — before final composition can PASS.** Inventory every visible text string in the overlay (title, labels, values, badges, card text, CTA, callouts, chart labels, handles/URLs). Proofread them against the full script, `quote`, `talking_point`, `visual`, and domain context. Any typo, grammar issue, missing Vietnamese diacritic, wrong casing, wrong number/currency/%/symbol, wrong proper noun, wrong industry term, or awkward machine-written phrasing = Gate 4/7 FAIL. Do not let a clean dead-zone/layout result hide bad copy.

> **⭐ THE AGENT DECIDES — autonomously. The user is NOT present at runtime.** This playbook is only the rails; every decision belongs to the running agent. The user delegated the whole job and reviews only the FINISHED video — so **never block on a question** ("do you want…?", "which one should I use?", "should I rebuild?"), never present options for approval, and never wait for input that won't come. Pick the best action using the master decision protocol, act, and surface anything noteworthy in the final hand-off.

> **⭐ REGENERATE-OR-LEAVE THRESHOLD** — the core decision for every existing overlay:
> 1. **Vision gate — can you see images?** **NO (pure-LLM, no vision):** do NOT rebuild the overlay (you can't judge the result) — limit yourself to **safe data-driven layout fixes** (`layout.batch` to clear `narrator_face` when `show_narrator=true`, pull an object out of a dead zone, stop caption overlap); otherwise **leave the overlay as the pipeline made it.** **YES (can see):** pull the screenshot, save it locally, show it visibly to the user, and **only then** look/evaluate it, then gate 2.
> 2. **Quality gate — would your new SVG be clearly BETTER?** Rebuild **only when, after looking, you're confident the new overlay is BOTH more beautiful AND more correct** (more legible / on-message / on-vibe / a real defect fixed). Good enough → **LEAVE IT.** "Different" ≠ "better". **Mandatory rebuild triggers:** title/hero text is dark, muddy, low-contrast, thin-bodied, over-stroked, not prominent, or only repeats a panel label instead of stating the scene takeaway; labels are too small to read in the 280×498 screenshot; text collides with icons/cards; decorative effects make words harder to read. These are content failures, not mere polish.
> 3. **Context** — a HOOK / KEY POINT earns more polish than a filler beat; a concrete defect (text sinking, tiny labels, off-message, edge-clipping, missing info) → rebuild; no defect → leave. **Endpoint scenes:** scene 2, thumbnail sync, and the final CTA must look like a poster/magazine cover/CTA poster, not like a normal inside-scene card. If the current endpoint overlay is just a centered card, horizontal text bar, or plain title/subtitle panel, treat that as a style defect and rebuild into a named endpoint style from `40_thumbnail_cta.md`. **Final A-roll / CTA exception:** when the scene is the last non-thumbnail/content scene and `show_narrator=true` / `active_roll="A"`, first load `40_thumbnail_cta.md`: the narrator is normally the close, and the CTA should be one clear typography-led action. Prefer full-canvas narrator first. Do not rebuild a large object-heavy SVG just to satisfy `visual` if a short CTA line plus narrator carries the close better. If the current overlay competes with the face/human close, remove/disable it only when the visible narrator + caption already carry the CTA; otherwise reduce/reposition/rebuild it as a small strong text support element. Only use the fallback shrunken-narrator priority when a detail-dense final visual is truly indispensable.

**What you can build, and what you can't:**
- **You BUILD the overlay as SVG — free, full control, server converts.** Text / numbers / diagrams / charts / quotes / lists / callouts / icons / simple vector illustration → all authored as SVG. No image generation, no cost. **The authored SVG itself is visual evidence:** save the `.svg` locally and show it to the user before you evaluate it, host it, upload it, or overwrite the scene spec.
- **A realistic PHOTO you cannot draw is NOT created.** Either (a) **reuse** an existing one — embed it in the SVG via `<image>` (§5.4) — or (b) step down to an **SVG text/graphic** that carries the same message.
- **The scene BACKGROUND (real footage) is a separate decision — §4** (`search_broll` / `mediaUrl`), not part of overlay authoring.
- **Layout-only problem** (position/size/dead-zone, content still right) → don't rebuild; `remotion.object.rect` / `layout.batch` (§5.5).

### 5.1. The SVG standard — every overlay

- **`viewBox="0 0 720 1280"`, transparent.** Never paint a full-canvas background rect (it would hide the scene). No chroma, no keying.
- **Each logical object = one `<g data-wc-object="id" …>`.** The server maps every marked group → ONE Remotion object (cropped to its bbox, transparent PNG) at its exact position. Group attributes:
  - `data-wc-object="car"` — stable id / name (used later for `layout.batch`).
  - `data-wc-kind="text|object|bar|callout|mark"` — optional; auto-inferred (a group with only `<text>` → `text`).
  - `data-wc-anim="…"` — **entry animation, FULL vocabulary** (12 + 2 bar), any object incl. text. Accepts a friendly alias OR the raw engine name: `fade · slide-up/down/left/right (slideUp/…) · scale(scaleIn) · zoom(zoomIn) · pop/bounce(bounceIn) · spin(rotate) · roll(rollIn) · flip-x/y(flipInX/Y) · grow-x(growRight) · grow-y(growUp)`. Unknown → `fade`. A **bar** is forced to growRight/growUp. Vary the entry between objects/videos for life.
  - `data-wc-z="2"` — paint/stack order (default = document order).
  - **`data-wc-delay="0.6"`** (seconds) — exact reveal time for that object (sequencing / overlap control).
  - **`<g data-wc-seq="0.4">…</g>` — LINE-BY-LINE (accumulate).** Auto-staggers its child `data-wc-object` groups (delay = step × 0,1,2…) so they appear one after another and **STAY** (the full set is visible at the end). Good for building up a sentence/list.
  - **`<svg … data-wc-ani="one_by_one">` — TRUE ONE-BY-ONE (replace).** Only ONE object on screen at a time; each is **replaced** by the next (you end on the LAST one — you never see them together). The engine splits the full scene window into N equal slots, **ignores per-object delays/`objects_duration`, and AUTO-POSITIONS** the lines (top-center safe zone; or `data-wc-textpos="bottom"` = lower band, which **auto-clears an upper narrator face** on A-roll — no manual move needed). `data-wc-hold="0.8"` holds the final line longer. Use for a run of self-contained punches/phrases. (Also: `data-wc-ani="all"` = default accumulate · `focus_zoom` · `breath_pulse` · `data-wc-campan="left_to_right|right_to_left"`.)
  - To reveal **all at once**, set `data-wc-delay="0"` on every object; with **no** delay/seq/ani attrs the server auto-staggers (accumulate) by default.
  - **`data-wc-sfx`** — reveal sound. By default the **top-N largest objects auto-get a sound** mapped from their entry (same engine map as native specs — whoosh/pop/click…). Override per object: `data-wc-sfx="reveal1.mp3"` to force a file, or `data-wc-sfx="none"` to mute.
  - A nested **unmarked** `<g>` inside is fine (visual grouping only); a marked group is **atomic** (the server doesn't split it further).
- **Grouping IS the animation unit.** Everything in ONE group animates together; separate groups animate independently. There is **no spacing/merge math** — grouping is explicit (this replaces the old "space objects apart so they don't merge" rule).
- **Position is exact + reproduces pixel-for-pixel.** viewBox = the 720×1280 canvas, so each group's bbox = its true canvas position. Keep all content in the safe box **x ∈ [36, 684], y ∈ [128, 960]** (5% sides; 128px top dead-zone; 320px bottom reserved for the caption). The server vertically auto-fits the group into the safe band — keep the content **compact**; for an exact vertical spot, set it afterward with `layout.batch` (don't rely on your source y surviving).
- **Composition before anchoring:** for B-roll / faceless / non-face-critical overlays, if the title and all supporting objects can fit as one compact group inside the safe box, design them as a cohesive center-safe composition. The title may be above the objects, but it should visually belong to the group; avoid a lonely top-safe title with the chart/steps/cards stranded near the caption. If the first center-safe draft covers an important real background face/product/prop, move the whole group lower/higher within the safe box instead of splitting it apart again. Use a top-safe title only when the group cannot fit centered, the footage needs that separation for readability, or A-roll face clearance forces it.
- **Font — use the renderer's font so preview == final video, and pick it per §5.2.** Derive the family **per video** and **name the HEAVY variant** (e.g. `font-family="Be Vietnam Pro Black"`) — **cairosvg ignores numeric `font-weight`, so a bare family name renders the thin Regular** (the recurring thin-text bug); see §5.2 for the full font/weight/size rules. The server renders the SVG with the same font set the Remotion renderer uses, so the preview/poster matches the rendered video. Any family in the renderer set is fine (Be Vietnam Pro has full Vietnamese coverage); don't name fonts that aren't in it.
- **Colors are free** — there is no chroma constraint. Use any palette (derive the accent — §5.2).
- **Text readability + padding standard (mobile screenshot standard):** design for the final 280×498 composite, not for a zoomed SVG editor. Title/hero text should use a bright fill (white / warm yellow / light cyan / other high-luminance color) plus a controlled dark stroke/shadow when needed; the title must have a visibly thick letter body from the font/size, while the outline stays thin/controlled — **body dày lên, viền mỏng thôi**. Avoid black/dark fills on saturated or dark footage. **Secondary labels/values/card text are different: they should have NO visible stroke/outline at all.** Make them short, bold, solid-filled, and separated from icons with real spacing. Prefer open text on a quiet area or a subtle no-border backplate; use a chip/card/border only when it adds clarity. If a small label needs an outline to survive, the design is wrong — enlarge it, simplify it, move it to a quieter area, or give it a proper background. If a label is readable but crowded against its chip/card/bar border, the design is still wrong. A text box being inside `safe_rect` does not mean it is readable or tasteful.

### General drawing rules (apply to every graphic — charts & patterns)

Draw per the scene's `pattern` / `sub_mode` / `visual`. **`visual` is the authoritative description** of what the overlay should contain — keep its **anchors** (figures, %, years, names, terms) and copy them **verbatim** (plus `quote`/`talking_point`), whether you rebuild the whole overlay or only a missing part — never invent. Put **each node / bar / step / label / connector / list-item / icon in its own `<g data-wc-object>`** so each animates on its own (see MAXIMAL GRANULARITY in §0.5) — a **list = one object per item**, and **the item's check/bullet/number is its own object, separate from the text after it**; **bars** get `data-wc-anim="grow-x"` (horizontal) or `grow-y` (vertical).

- **Spatial specificity:** when the narration names a position/angle/area/point, the visual must depict it (e.g. "T-bone at the right passenger door, 3/4 front-right", a callout onto the exact field) — not a generic placeholder.
- **Callouts / marks** are SVG's home turf: an `<ellipse>`/`<circle>` outline (no fill) + a leader `<line>`/`<path>` + a small `<text>` label, all over the thing being marked — put the whole callout in one `data-wc-object="callout"` group.
- **⭐ Draw every mark / icon / arrow / check as a VECTOR SHAPE (`<path>`/`<polyline>`/`<circle>`), never a font glyph.** The renderer font may not contain `✓ ✗ → ➜ ★ ● ☑` etc. → they render as **tofu boxes** (verified: drew all checks/crosses/arrows as `<polyline>`/`<path>` this session). A check = a 2-segment `<polyline>`; a cross = two `<line>`s; an arrow = a `<path>`/triangle `<polygon>`; a bullet/number badge = a `<circle>` (+ a `<text>` number inside). Plain quote marks `"` `"` and the middot `·` ARE safe in the sans families; emoji/dingbats/arrows are not.
- Each text element ≤5 words; the scene's language (VI keeps diacritics); pack the anchors into title/label/callout.

### 5.4. Reuse an existing realistic image (NOT creation)

When a scene genuinely needs a **realistic photo you cannot draw** and one already exists, **reuse it inside the SVG** — never claim to create it:
- **⭐ If the existing overlay is GOOD and you only need to ADD a missing label/stat/callout (no restyle, no recompose) → don't rebuild at all: `modify_scene` (M) `remotion.add_element`** (FREE, additive, does NOT overwrite the spec or disturb the photo). This is the cleanest path for the preserve case. Reserve the extract-and-rebuild path below for when you must ALSO restyle/recompose (which requires a full re-author + overwrite).
- **From the current spec** (the narrow "preserve" case — applies when the existing realistic image is good + on-topic and the ONLY problem is missing info): **extract it BEFORE you overwrite.** The spec embeds the image as a base64 PNG — the **longest string** at `elements[].props.objects[].image` (prefix `data:image/png;base64,`). Decode it to a local image file, show that local image to the user, and **only then** inspect/reuse it (it's a clean transparent cut-out), then embed it in your SVG:
  `<g data-wc-object="photo"><image href="data:image/png;base64,…" x="…" y="…" width="…" height="…"/></g>`
  and add the missing info as other groups (text/stat) with the anchors copied from `visual`. **Use the data URL form for extracted spec photos. Do not upload the extracted PNG and point the SVG at an external `https://…` URL as the primary path: `svg2spec` can omit/fail remote `<image href>` during conversion, leaving the photo missing in the final poster.** If you need to host the extracted PNG for record-keeping, that is separate; the SVG that you upload should still carry the extracted photo as a `data:image/...;base64,...` href. *(Verified on a STAT scene: the spec held a damaged-car cut-out; an external S3 `<image href>` failed to render, while embedding the extracted PNG as a data URL preserved the car and allowed the `$500×3 = $1.500` stat rebuild.)*
- **From a found asset / user-supplied image:** same — download/save it locally and show it before judging or embedding. Prefer embedding it as a data URL when the image is part of a rebuilt SVG spec, especially for one-off overlays; use an external `<image href="https://…">` only if the final post-upload screenshot proves the remote image actually rendered.
- Otherwise default to a **text/graphic SVG** that carries the message. The scene **background** footage is §4, not this.
> ⚠️ **ORDER MATTERS:** `upload_overlay` OVERWRITES `{voice_file}_spec.json`. For any scene whose existing photo you want to keep, **extract it FIRST**, then save/show the new local SVG preview, then upload your new SVG. Once overwritten, the original photo is gone from the spec.

### 5.5. Apply & verify

1. **Save/show the local SVG BEFORE hosting/uploading.** Write the authored SVG to a local `.svg` file and show that local file visibly to the user before any `upload_asset`, PUT, or `modify_scene`. Do **not** convert/rasterize it into PNG/JPG as a preview step; that burns time and can diverge from the server renderer. Do not inspect the SVG privately and do not upload first/show afterward.
2. **Host the SVG, then upload.** `upload_overlay` takes a **URL**, not raw markup — so after the local SVG has been shown, host the `.svg`: **`upload_asset`** (presign, `content_type="image/svg+xml"`) → **PUT** the SVG bytes to the returned presigned PUT url → take the returned **GET url**. Then `modify_scene` (B) `remotion.upload_overlay` (FREE), `by="voice_file"`, value = that `.svg` GET url. (Same host-then-apply mechanism as a background asset, §4.1b — only the field differs.) The server detects SVG → `svg2spec` → spec + poster. **You do NOT upload a JPG/PNG — the server renders the SVG.** The pre-upload local SVG is only a transparency/content gate; final render truth still comes from the post-upload screenshot (step 4).
3. **Fine-tune position/scale** if needed: `modify_scene` (G) layout edits, FREE. Use `layout.batch` wrapping `remotion.object.rect` (`layout_id` from the object id + `x/y/w/h` in preview space) when moving 1–12 specific objects. If you are translating the whole SVG overlay together, or the SVG decomposed into more than 12 objects, use `remotion.group.rect` on the Storyboard group (`element_id:"main"`, `x/y`, `coordinate_space:"preview"`) instead. If the group is too tall for the safe band, do **not** jump straight to rebuild: first try move-only group translation; if that trades a top violation for a bottom violation (or vice versa), use whole-group resize (`w/h`, `resize_mode:"scale_children"`). If the whole title+object group does fit, prefer a center-safe group placement over a top-safe title plus low/scattered objects. Rect edits only **move/resize**; they can't restyle, so after resizing you must re-check title and secondary readability from a local-shown screenshot. Rebuild the SVG only when the resized group makes typography too small/muddy/cramped or otherwise fails the text gates.
   > **⚠️ A-ROLL (`show_narrator=true`) — THE OVERLAY DOES NOT AUTO-AVOID THE FACE.** Unlike the native typography path, an `upload_overlay` SVG is **auto-fit CENTERED in the safe band** → it can land on the narrator's face. So for any A-roll scene you MUST already have the Gate 4 A-ROLL LAYOUT PRIORITY PROOF from `10_mechanics`, then use `scene_geometry` to read `narrator.face` and place/tune the overlay according to the chosen priority: above the head when priority 1/2 selected that upper placement, or below the face/chest band when priority 1/3 selected lower placement. The hard requirement is not "always below the face"; it is **face fully clear + no dead-zone intrusion + readable overlay + caption clear**, proven from the local-shown screenshot. For lower-band placements, keep overlay object tops below `face.y + face.h` with margin and above the caption; for above-head placements, keep overlay bottoms above the face with margin and out of `dead_top`. **Never assume auto-placement cleared the face — use a local-shown screenshot.** **Cleaner for typography:** use `data-wc-ani="one_by_one" data-wc-textpos="bottom"` when the Gate 4 priority chooses a lower text band — the engine then auto-places the lines in the lower band and clears an upper narrator face; for upper-band or static/accumulate overlays, tune via `layout.batch` / `remotion.group.rect` according to the chosen priority.
4. **Verify with a composite screenshot** (`scene_inspector` → `screenshot_scene_280x498`) — not the static poster. Save the screenshot to a local file and show it to the user before evaluating. Confirm only after the local image is visible: **title/hero text is bright, thick-bodied, prominent, semantically the scene takeaway, and typo-free/grammar-correct; every secondary label/value/card line is copy-correct, readable without zoom, has no visible stroke/outline, is not covered by another label/badge/object, and has visible inner padding from any chip/card/bar border; no text is dark/muddy/thin/blurred/cramped or touching/grazing a border**, objects placed right, VN diacritics clean, nothing clipped. If the problem is copy correctness, styling/readability/title/label quality, or missing text-container padding, **rebuild the SVG**; `layout.batch` is only for position/size, not for fixing bad copy or bad typography.
   > **⭐ DEAD-ZONE CHECK — mandatory on every overlay review.** Confirm **NO overlay object or text sits in a dead zone**: `dead_top` (canvas y < 128 / preview y < 49.8) or `dead_bottom` (canvas y > 960 / preview y > 373.5). The authoring safe-box only governs your SOURCE positions — the server **vertically auto-fits** the group, A-roll **auto-centers** it, and any layout edit can push an object out, so content CAN land in a dead zone after upload. Cross-check the local-shown rendered screenshot **against `scene_geometry` object rects vs `safe_zones`**. If 1–12 individual objects intrude, pull them back into `safe_rect` with `layout.batch` (`remotion.object.rect`). If the whole overlay group intrudes, use the group ladder: **move whole group first; if moving creates the opposite dead-zone violation, resize the whole group; rebuild only if the resized typography fails readability**. Re-verify with another saved/shown local screenshot. (The caption owns `dead_bottom` — overlay content stays above it; nothing in the top notch band either.)
5. **Lock the spec**: `remotion_spec` → `{voice_file}_spec.json?v=<ts>`. If `remotion_spec=="none"` (the user disabled the overlay) don't re-enable unless asked.
