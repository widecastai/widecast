# Jump-Prevention Rules — catch yourself BEFORE the action

Each line below is an **interrupt** on what you are *about to* do. If the trigger matches what you're about to do next, **STOP**, do the `→` part first, then resume your task.

This list is deliberately redundant with the Critical Rules (`ai_video_editor/01_critical_rules`) and the per-scene Definition of Done (`ai_video_editor/03_dod_gates`) — **redundancy is what stops misses**. Load this module at the START of every run, and re-load it whenever you do a Gate Resume Scan after a detour.

---

- About to **start a scene** → first load `ai_video_editor/10_mechanics`.

- About to **handle the first real scene after the thumbnail** → first load `ai_video_editor/40_thumbnail_cta`; it is the opening poster frame even if its `type`/`pattern` is not `thumbnail`, and it needs a named endpoint poster style rather than a normal card/text-bar overlay.

- About to **handle `type="thumbnail"`** → only do this as the immediate sync gate after scene 2 PASS (unless the user explicitly asks for a thumbnail-only debug/edit). First load `ai_video_editor/40_thumbnail_cta`; clone/verify the opening poster identity, then continue to scene 3.

- About to **handle the last non-thumbnail/content scene or `type="CALL TO ACTION"`** → first load `ai_video_editor/40_thumbnail_cta`; treat it as the closing CTA endpoint, with one clear action, typography stronger than decorative objects, and poster-grade composition rather than normal inside-scene card styling.

- About to **ask what kind of edit / edit scope** after the user gave a WideCast URL or `topic_id` (`What kind of edit do you want?`, `Full audit + fix / Specific scenes / Backgrounds / Text`, `Before I touch anything...`, `edit this video can mean different things`, `Asking Edit scope`, `request_user_input`) → STOP. The scope is already **Full audit + fix**. Do not ask. Continue the autonomous run from `video_data` → whole-video context → scene 2.

- About to **audit/choose the background** → first load `ai_video_editor/20_background`. (Background is its OWN pass immediately after overlay, never folded into the overlay.)

- About to **start Gate 6 / final composition work** and this scene does not yet have a printed `Gate 5 BACKGROUND PROOF` with a PASS/FIXED verdict → STOP. Run Gate 5 first. Overlay urgency, obvious text errors, or "the screenshot looks fine" do not waive background proof.

- Just finished any **detour/fix** (wrong term, typo, missing number/symbol, bad overlay word, covered face, wrong thumbnail, background swap, geo mismatch, layout tweak, tool/debug issue, or cross-scene small fix) and feel ready to summarize/handoff/move on → STOP. Run the Gate Resume Scan from Critical Rule 12c (`ai_video_editor/01_critical_rules`) and continue from the earliest unchecked or invalidated gate; a fix is not a scene/run verdict.

- About to **(re)build, apply, or approve an overlay on A-roll** (`show_narrator=true`) without a printed Gate 4 A-ROLL LAYOUT PRIORITY PROOF → STOP. Load `ai_video_editor/10_mechanics`, run the full-canvas-first ladder inside Gate 4, and decide the overlay/narrator tradeoff before drawing/uploading/accepting the overlay.

- About to **(re)build or apply an overlay** → first load the whole LOAD CHAIN: `ai_video_editor/30_overlay_core` + `ai_video_editor/10_mechanics` when A-roll + the matching `31`/`32`/`33` + its `styles/*`. Stopping at `30_overlay_core` = flat / off-pattern.

- About to **make ANY visual call** (grid-vs-real, regenerate-or-leave, readable?) from `scene_geometry` alone → STOP: pull the screenshot, save + show it locally, judge from the IMAGE. Geometry never substitutes for looking.

- About to **act on a screenshot / found media you have not SHOWN** locally → save + show it first (Critical Rules 0/11).

- About to spend time **rendering/converting an overlay preview** before upload → STOP. Only show a pre-upload overlay preview if the runtime already has a cheap direct display/conversion path; otherwise upload/apply the overlay and verify via the post-upload composite screenshot (Critical Rule 4).

- About to **ask the user to choose/approve an option during runtime** → STOP. Use the decision protocol in Critical Rule 2a, choose the best option yourself, act, and only report the decision/proof. Do not turn uncertainty into a user question.

- About to **declare `Scene N: PASS`** without scanning all 9 DoD gates + §7 Quality Standard (incl. module coverage + final composition/dead-zone) → run the scan first; PASS is earned by the scan. The DoD lives in `ai_video_editor/03_dod_gates`; the Quality Standard lives in `ai_video_editor/05_quality_qa_priority`.

- About to **declare `Scene N: PASS`** but the end checklist cannot name the Gate 5 verdict (`PASS keep`, `PASS grid-by-design`, or `FIXED + PASS`) → STOP. The background audit is missing even if overlay/composition passed.

- About to **declare `Scene N: PASS` / final handoff** but the `MODULE COVERAGE GATE` has any missing required module → STOP. Load the missing module at the correct step, resume the earliest invalidated gate, then re-scan.

- About to **move to the next scene** with no stated `PASS`/`FAIL` verdict → declare the verdict first. No verdict = scene not done.

- About to **write a final summary / completion report / Telegram completion message / export question** → STOP and run the Pre-summary completion scan (Critical Rule 12d). If any scene/gate/ledger row is incomplete, do that work first instead of summarizing.

- About to **final-handoff a video** without a complete per-scene background-audit ledger for every content scene → STOP. Say "background audit not complete" and run the missing Gate 5 rows before hand-off/export.

- User asks **"did you audit backgrounds?" / "are backgrounds suitable?"** → answer from the Gate 5 ledger only. If any content scene lacks a Gate 5 proof row, answer "not yet" and continue the background audit; do not infer from memory or from overlay screenshots.

- **Resuming / continuing a run** → do NOT work from memory: re-load the modules for the step you are on.
