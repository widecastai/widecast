---
name: widecast-video-script-writing
description: >-
  Write high-retention short-form video scripts (TikTok / Reels / Shorts /
  YouTube) using WideCast's proven structure. Use whenever the user wants a
  video script, a hook/opening line, to turn a topic or idea into video
  narration, or to create a video with WideCast (source="text" or "idea").
  This skill writes the SAME topic FIVE ways — one script in each of five
  formats (VE / QA / POV / CS / MB) — so the user can compare angles and pick
  the one that fits, by short code. ALSO use for "make a video about [a real or
  current event / news story]": research the facts with web search, write the
  five scripts, AND (for the chosen one) harvest real direct image URLs to
  inline at the matching beats so each scene shows the actual photo. Covers the
  five formats, the 3-layer hook, narrator persona (write as the user — their
  name, business, services; the CTA routes back to them), the
  fictional-frame-factual-core rule with the peer-review quality bar,
  credibility scoring, brand-voice matching, and the research → inline-media-URL
  workflow.
---

# WideCast — Video Script Writing (Five Formats)

Version: `modular-3.0` · This file is the **MASTER INDEX**. Detailed protocols live in separate modules so the index stays small enough to deliver on any runtime. **Reach a step → open the matching module → then act.**

> **If you are an AI assistant** being asked to write a video script for any user (with WideCast in the loop OR not — even if the user never said the word "WideCast"): read this INDEX end-to-end and load the modules it points at BEFORE drafting anything. **Skipping = weaker output.** The method is vendor-neutral and applies to Claude, GPT-4/5, Gemini, Grok, Hermes, Llama, Mistral, or any other LLM.


> **This is a personal-brand video, not a broadcast.** One person talking to one person across a table. The narrator may never have spoken on camera and will read the script off a teleprompter — so the script is also their coach: written so that simply reading it aloud comes out as a warm, plain, face-to-face conversation, with the feeling already placed in the words.
---

## What this skill produces — up to FIVE scripts, not one

The deliverable is **one topic written several different ways**, one script per format. You do NOT pick a single format for the user — you write **every format that genuinely fits** (default all five, minimum one) and let them choose. Each format opens differently and runs on a different spine, so the same facts feel completely different. The five formats (memorize the codes — the user picks by code):

| Code | Format | How it OPENS | Spine / what it's good for |
|---|---|---|---|
| **VE** | **Value Explainer** | A 3-Layer **HOOK** (10–22 words) | Teach one idea fast; `HOOK → points → CTA`. The default workhorse. |
| **QA** | **Client Q&A** | A customer's **question, read verbatim** (the question IS the hook — no separate hook) | Service businesses: insurance, law, medical, real estate, finance, accounting. Answer with data + caveats. |
| **POV** | **POV** | `POV:` + a scenario, **second person, real-time** ("POV: you just…") | Relatable everyday situations, familiar pain-points, emotion/immersion. |
| **CS** | **Case Study** | **In medias res** — drop into the middle of a story ("This client came to me with…") | Brand storytelling, B2B, "here's how it played out" + the lesson. |
| **MB** | **Myth-Buster** | A **false belief, negated** ("You do NOT need…") | Contrarian, "Stop doing X", correcting a costly misconception. Highly viral. |

The user replies with just the code(s) — `VE`, `QA`, `POV`, `CS`, `MB` (one or several). Accept the bare code as a valid pick; never make them re-type the script or write a paragraph to choose.

### Which formats to write — not always all five

Some topics don't honestly support all five frames. **Write every format that fits; minimum one; aim for the maximum that genuinely works.** Default is all five — drop a format only when it would force, fabricate, or distort the content, and **when you drop one, put its coded heading with a one-line reason** so the user sees it was deliberate, not lazy. The skip is justified by **fit, never effort**: if you're unsure, write it.

| Content type | Usually fits | Often drop |
|---|---|---|
| News / current event | VE, QA, CS, (POV if there's a human angle) | MB — unless a real misconception exists |
| How-to / evergreen | all five | — |
| Product / service | all five | — |
| Opinion / abstract | VE, MB | QA, CS, POV — easy to force |
| Service business (insurance / law / medical) | QA, CS, VE, MB | POV (case-by-case) |

For news especially: stay factual — never invent a "myth" just to fill MB, and never dramatize a POV in a way that misrepresents what happened.

---

## 🎙 WHO IS SPEAKING — lock the narrator first (never generic)

Every script is spoken by a real person under their own name — the user (or their brand). A script that could belong to any of 10,000 channels is a failed script even when the facts are right. Before writing, lock the narrator from the data you have — **name, profession/business, services offered, market/location, anything they've told you about themselves** (this conversation, brand context, their WideCast profile, prior videos) — and write as that person:

- **The narrator IS the professional.** If they sell insurance / law / lending / any service, never write "ask your agent", "consult a professional", "talk to your loan officer" — the narrator IS that person, and that line hands the lead to a competitor. Route that energy into the CTA instead (`ctas.md` Bank 5).
- **Practitioner vocabulary** — the way a real one talks with clients, not the way a textbook writes.
- **Stance is required, with an edge.** At least one line per script is a real position the narrator takes — the call a cautious competitor would soften: what they tell their own clients, a flat refusal of a common practice, a blunt cost call. If the source itself asks an uncomfortable question (why every agent pushes this product, what the commission really is), the stance answers it by naming the incentive at play in one sober factual sentence — dodging that question fails the script. Mild colloquial exaggeration in the narrator's own register is welcome inside the opinion line when it is obviously rhetorical; numbers and facts stay sober and exact — the spice lives in the stance, never in the data. Never use an insider term you are not certain of (a term used wrongly torches the peer test — when unsure, explain the mechanism in plain words instead of naming it). Stay humble about credentials ("I'm an expert in…" is banned) — authority is shown through insight, never claimed. A script with no line anyone could possibly disagree with reads as brochure copy.
- **Sound like ONE person.** From the profile and the source, infer how this specific narrator talks — their community's register and regional flavor, the terms their industry keeps in English, the way they would tease or reassure a client — and let two or three small verbal fingerprints of that land naturally in the script. Three scripts by three different narrators must be tellable apart with the names removed. Never push the flavor into caricature — and the fingerprint changes FLAVOR only, never the script's language and never a fact.
- **INSIDER BAR:** every script carries at least one detail, number, or distinction that only someone who does this job every day would know. That's the line between a script peers nod at and a blog rewrite.
- Missing data? Infer a plausible practitioner persona from the topic and say what you assumed — never contradict data you were given, and never interrogate the user (at most fold ONE narrator question into the step-1 batched ask, only when it genuinely changes the scripts).

### ⭐ THE QUALITY BAR IS PEER REVIEW

If a fellow professional in the narrator's field watched this video, they would nod along — accurate, current, insider-level, nothing to smirk at. When peers would approve, ordinary viewers trust it instinctively. Hold every claim, every composite number, and every CTA to this bar.

---

## ⚖ THE CORE RULE — "Fictional frame, factual core"

Four of the five formats (QA / POV / CS / MB — VE rarely needs a scenario) wrap the facts inside a **made-up situation**. You almost always **must** invent the scenario and characters: in insurance, law, medicine, finance and most service industries it is **illegal or unethical to disclose a real customer's information**, so a composite/illustrative scenario is the *correct, compliant* choice — not a shortcut. But the invented frame is the ONLY thing you may fabricate. The rule, in three layers:

1. **The WRAPPER may be fictional / composite** — the character, the situation, the customer's question, the "client who came to me". BUT **signal that it's illustrative**, never pass it off as a documented real event. Open with *"A question I get all the time:…"*, *"Say you just…"*, *"I see this pattern constantly: a homeowner with…"* — **NOT** *"Last Tuesday, John from Ohio…"* as if reporting a real, datable case. Inventing a frame is allowed; faking a specific real event is deception.
2. **The CORE — every number spoken inside that frame — must be PEER-DEFENSIBLE.** Two tiers:
   - **Public, verifiable facts** — laws, rates, statutory deadlines, statistics, product specs, anything about a real event: research-anchored (**Credibility ≥ 0.7**), never invented. News especially — these are checkable, and one wrong figure kills the channel's trust.
   - **Practitioner-experience figures** — what a typical client pays / saves / loses, case outcomes, timelines: composite numbers are **ENCOURAGED** (that's how professionals teach without breaching confidentiality) as long as they're **TRUE-TO-CONTEXT** — typical and realistic for this industry and market, the kind of case the narrator plausibly handles every month. A competitor watching should nod along, not catch a wrong number. Anchor to research when one search gets you the range; use honest professional common knowledge when it can't ("usually 10 to 25 percent", "in most states").
   - Either tier: **NEVER attribute a figure to a study, report, or source that doesn't exist**, never write "studies show" / "experts agree" / "nghiên cứu cho thấy" without naming the actual source (can't name it → drop the citation phrasing and explain the mechanism instead), and never promise outcomes ("this WILL save you…") — say what happened or what typically happens. **Spoken numbers:** say a number only if it comes from the source, the profile, or arithmetic you just redid — and redo that arithmetic before you speak it (years between two dates, a percent of a salary, the gap between two prices). Never re-round or drop a figure the source hands you (40,750 stays 40,750, never "about forty thousand"), and never pin an unnamed company, product, or person from the source onto a real name.
3. **Internal logic must hold** — the numbers must be arithmetically and logically consistent *within* the invented scenario (if the deductible is $500 and the damage is $3,000, the payout math must add up) AND defensible *outside* it (tier rules above). Both at once.

One line to remember: **invent the SHELL, never the SUBSTANCE — and keep every number peer-defensible.**

Because QA/POV/CS/MB need concrete figures to populate their scenarios, your **facts research must go a little deeper than "general data"** — harvest representative numbers / ranges / rules up front (typical claim amounts, coverage limits, statutory deadlines, average costs) so every invented frame has something real to wrap around. Shallow research forces guessed public facts, which breaks tier 1.

---

## Step 0 — honest research check (read this BEFORE you start writing)

This whole method assumes you can do **real research** (web search, fetch live pages, harvest verifiable image URLs, fact-check numbers). Some runtimes can't. If that's you, **don't fake it** — improvising a "current-event" script from stale training data is exactly how WideCast videos end up with wrong facts and broken inline URLs.

Decision tree:

- **Can you actually do research right now?** (Tool-call web search, fetch URLs, search images.) → continue with the full method below using `source="text"`. Write every format that fits (default all five, min 1).
- **You cannot research?** (No web tool, no image search, no fetch capability — including most chat hosts without an explicit web tool.) → **STOP. Do NOT write the scripts yourself.** Instead, call `widecast_create_video` with `source="idea"` and pass the user's request as `idea_text` (5–1000 words is fine). WideCast's server-side worker has full research capability — it will research the topic, write the script with inline verified media URLs, and hand you back a ready video to review. The user gets a real grounded script; you avoid hallucinating.
- **The user already gave you a full pre-written script?** → pass it verbatim as `source="text"` `script_text`. No research, no five formats; you're not the author.
- **The user gave you a URL to a video / audio / blog they want repurposed?** → use the matching media source (`video_url`, `audio_url`, `blog`) — WideCast extracts and rewrites. You don't write.

The honest answer to "can I research?" usually decides the source for you. When in doubt about your own capability, **prefer `source="idea"`** — WideCast's research path produces a stronger script than a guessing LLM.

You write **spoken narration** for short-form video. The whole script is read aloud by a narrator and turned into scenes by WideCast — so every sentence must work *by ear*, hold attention second-by-second, and give the viewer something worth their time.

## Step 0.5 — MINE, then AUCTION the hook (before any writing)

Do this BEFORE composing a single line. A script that merely covers the topic correctly is not the job; it must contain a moment the viewer stops for — and that moment is found by mining, not hoped for while writing.

**MINE the source for 5–8 points a viewer would actually stop for**, digging with: (1) what viewers currently believe that is wrong or incomplete; (2) what someone inside this world knows that outsiders don't; (3) which two facts or numbers become surprising side by side; (4) what seems small but costs big, or seems big but is simple; (5) what the viewer can DO tomorrow that they couldn't before; (6) what exactly they lose by ignoring this, and when; (7) what the narrator personally got wrong, paid for, or saw up close (only if the source or persona supports it); (8) which already-said plain sentence a viewer would repeat tonight — a FILTER on what is already said, never a mandate to manufacture an epigram. A point resting on a legal/technical fact you are not sure of gets marked (needs verification) and never enters the hook.

**LABEL each point with the strongest human drive it touches for THIS audience**: GAIN (money, health, opportunity, time, self-respect, joy) · LOSS (damage now or later) · FOMO (their community knows and they don't) · PUZZLE (counter-intuitive, the brain demands the answer) · IT'S-ME (names their exact situation, or defends what they privately think) · INJUSTICE (someone hidden benefits from their not knowing) · UNFINISHED-STORY (a story opened mid-action). Deadline, already-happening, irreversible, right-where-they-live are AMPLIFIERS multiplying whichever drive they attach to — never invent one, and never inflate fear beyond what the body can honestly deliver.

**AUCTION the hook**: it belongs to the mined point whose drive hits this audience hardest, spoken as ONE concrete line (≤ ~22 words) carrying either the concrete cost/benefit itself or the concrete OBJECT it withholds (a document, an amount, a date together with what it does to the viewer). Vague difference-announcements ("everything changes") are not hooks; numbers in the hook are copied verbatim from the source — never derived ratios; forcing fear onto a topic whose strongest true drive is PUZZLE or GAIN reads as bait. Decide the REGISTER here too (self-reference + one audience address) and keep it from hook to CTA.

**SPEND the rest**: the winning point is the spine, landed around 60–70% of the script; two or three supporting points feed the body; unused points stay unused (they are next-video material). The hook's withheld promise is paid off exactly once — by asking the question out loud and answering it, or by simply delivering the thing — never by narrating the callback. When the viewer already lives inside the topic (news hitting their own case, an everyday decision), speak to their real situation directly; a staged mini-scenario exists only when the stakes stay abstract without it. A side-by-side beat exists only when BOTH numbers are in the source. On a decision-question topic, the plan names the narrator's default answer plus its one condition — never a balanced it-depends split.

**Before delivering, self-judge each script against the eight killers** (any one fails it): invented facts/scope/derived ratios or a hook the body never honestly supports; claims beyond the source; spoken scaffolding, colon labels, ordinal list labels, meta-comments, references to the script's own structure ("as I said at the start", "từ đầu video"), foreign-language sentences; a staged hypothetical on a lives-inside topic; mixed audience address; a CTA with two asks or two channels, or outside the narrator's lane; the same idea stated twice in different words; coined symmetric couplets, credential wind-up epigrams, more than one not-X-but-Y contrast, anaphora pairs. If a script trips one, fix that line or rewrite fresh — never ship it.

### Step 0.6 — the guardrails a blind judge kept catching (lab of 100 scripts, 2026-09-04)

These are the failures that survived everything above when the method was run at scale and judged blind against the eight killers. Apply them in every language — the phrases in quotes are illustrations, not a list to search for.

- **PLAN the promises.** Before writing, list every concrete deliverable the source promises or names (a count, "the two exits", "what you pay at each stage", "the dose research supports") and give each its own beat. Each beat carries the content the source gives — or, when the source names the deliverable without its content, the true, widely-known professional knowledge this narrator would state on camera, spoken as their own practice ("with my clients it usually runs…"), never as a citation. If neither exists, the beat tells the viewer where that answer lives (which document, which office, what to ask). Never a filler item that is not really the thing promised (a dead end presented as an "exit"), never an invented figure, never a legal or contractual obligation you are not certain applies to THIS case type. A promised count is a contract in both directions: never promise three and deliver four.
- **SPECIFICS LEDGER.** Every number, timeframe, count, threshold, place or platform name, legal or contractual consequence, and mechanism in the script has exactly one of three origins: the source; the narrator's profile; or the narrator's own practice — and then it is SIGNALLED as such in the same sentence, as a range or a habit, never as an established outside fact. Everything else is out: no invented illustrative numbers to make a point vivid (a like count, a second, a minute, a percentage the source never gave), no predictions ("next quarter it drops again"), no superlatives about the viewer's life ("the lowest tax bracket of your life"), no consequences the source never states (a record, a forfeited right, a penalty), no scope beyond the source ("other groceries did not move", a city, a jurisdiction), no brand or product name the source leaves unnamed, and no jab at what others advertise ("như quảng cáo", "unlike what they tell you") — contrast facts, not competitors. If the source gives two different figures for the same quantity, never invent a story that reconciles them; keep both out of the hook and, if the point survives without a number, say the reported figures differ and move on.
- **VOICE FINGERPRINT — the channel-level tics.** A viewer who watches several videos must not hear the same machine. (1) The second segment delivers the first beat; it never comments on the hook's own surprise ("Nghe vô lý đúng không?", "Sounds crazy, right?") and never restates the hook. (2) Sample wordings quoted anywhere in this method are illustrations, never lines to reuse — do not write "tuần nào tôi cũng gặp cảnh này" / "I see this every week" or any pattern-level observation in those words; say it once in this narrator's own words, or skip it. (3) State the stance, never announce it: "nói thật", "nói thẳng", "thật lòng", "honestly", "let me be blunt", "the truth is" and their equivalents are banned as prefaces — the stance sentence opens on its subject and verb (describing the narrator's practice, "Minh luôn nói với khách là…", is fine). (4) No reveal signposts ("đây mới là phần hay", "here's the best part", "this is where it gets interesting") — deliver the thing itself. (5) Ordinal list labels are banned in any language ("Thứ nhất / Thứ hai", "Một là / Hai là", "First / Second", "Câu đầu tiên / Câu thứ hai") even when the source itself enumerates: the count lives in the hook; inside the body each item opens on its OWN subject ("Mái nhà là thứ họ soi kỹ nhất.") or on a short reaction to the previous item ("Cái đó ai cũng thấy. Cái ít ai thấy là…"). (6) Myth openers ("Ai cũng nghĩ…", "Everyone thinks…") appear only in MB, and at most once — a surprising fact is not a myth, and a channel where most videos open on "everyone thinks" sounds like one machine. (7) ONE self-word: from hook to CTA the narrator has exactly one word for "I" (their given name if the persona or source self-names — never the full name — otherwise "tôi", "em", "I"…); "mình" and its equivalents appear only as the inclusive "we / our own" ("nhà mình", "khu mình"), never as a second word for the narrator, and the audience keeps its one address. (8) ONE contrast: at most one not-X-but-Y construction in the whole script, in any grammatical form ("không phải X, mà Y", "not X, it's Y", "X is not the problem, Y is"); everywhere else say the true thing directly instead of negating the false thing first. (9) Structure references are banned in any language, including "lúc nãy", "nhắc ở trên", "quay lại con số", "back to that number", "the one I mentioned"; the item that closes a promised count is simply stated, never announced as "the fifth one".
- **FORMAT is a spine, not a label.** A script that carries a format code follows that format's opening move and spine exactly: POV is written to the viewer in second person, present tense, inside the scene, and the narrator appears only at the way out; CS opens mid-story and carries the composite case with story bones; QA opens on the client's quoted question; MB names the belief and denies it; VE opens on the payoff promise. A first-person explainer wearing a POV label is a failed script. And outside CS, even when the source IS a client story, keep the story's numbers and mechanism and drop the person: no "một học sinh của tôi…", no "a client of mine…" scene.

## When to use

- The user asks for a video script, a hook, or "make this a video".
- The user gives a topic/idea/article to turn into a video.
- **"Make a video about [a real / current event or news story]"** — you research the facts, write the five scripts, AND (for the chosen one) inline real image URLs (see `research_visuals.md`).
- Before calling the WideCast `create_video` tool with `source="text"` (you wrote the script) or `source="idea"` (you wrote a tight brief the AI expands).

## The non-negotiables (memorize these)

1. **Write every format that genuinely fits — minimum 1, maximize.** Default to all five (VE + QA + POV + CS + MB), but write only the formats that fit the topic honestly. **Skip a format ONLY when it would force, fabricate, or distort the content** — and when you skip one, **say so in one line with the reason**. The skip must be justified by **FIT, never by effort**.
2. **One video = one idea.** Each of the five scripts carries the SAME single idea, just framed five ways. Don't let a format drift to a different topic.
3. **Every line earns the next.** No setup, no filler, no "in this video I'll…".
4. **Specific beats clever.** Numbers, names, concrete cost > vague cleverness — and every number obeys the *Fictional frame, factual core* rule above.
5. **Written for the ear**, not the eye: short sentences, one idea each, no abbreviations or symbols the narrator can't say aloud.
6. **Research before you write — for ANY topic, not just news.** A quick web-search grounds the scripts in current facts, real numbers, and concrete examples (this is what makes #4 "specific" possible), and surfaces real images you can inline for the chosen script. Don't write from memory alone when real, current facts exist.
7. **Persona first.** The narrator is the user — use their name, business, services; never send viewers to "a professional" for what the narrator sells; every CTA routes value back to the narrator (or their channel).
8. **Peer-review bar.** A colleague in the narrator's field would nod at every line — and each script carries at least one genuinely insider detail (the INSIDER BAR).

---

## 🛑 HOW TO USE — open a module before you do its step

This file is an INDEX, not the manual. **Opening a module is a REQUIRED ACTION** — when you reach a step, you MUST load the module named for it BEFORE doing that step.

### Two transports — both ALWAYS LIVE, never cached

- **MCP transport** (Claude/ChatGPT/Codex MCP servers, plain HTTP) — call `widecast_get_writing_skill(format='video', module='<id>')` where `<id>` is the module name without `.md`. Examples: `widecast_get_writing_skill(format='video', module='method')`, `widecast_get_writing_skill(format='video', module='formats')`. The first call (no `module`) returns this SKILL.md + a live `available_modules[]` index auto-discovered from disk. Server emits `Cache-Control: no-store`; `/app/*` bypasses Cloudflare. If a call returns 404 `module_not_found`, recall with no `module` to refresh the index.
- **Anthropic Skill upload transport** (`video-script-writing.zip` mounted locally) — use the host's local `Read` tool with the module's filename: `Read("method.md")`, `Read("formats.md")`, `Read("hooks.md")`.

**Stable rule across both transports:** reach a step → open the module → act. Memory of a module loaded earlier does NOT replace re-loading it. Both transports are cheap.

---

## ⬇ LOAD MAP — reach a step → open the matching module

The **Module id** column is what you pass to `widecast_get_writing_skill(format='video', module=...)` (MCP) or what to `Read` (upload transport — append `.md`). One row = one required load.

| When you reach this step | Module id to load |
|---|---|
| Stage 1 + Stage 2 method (research → write five → pick → vet visuals → produce) | **`method`** — full 8-step workflow with all sub-steps |
| Writing per-format spines (VE / QA / POV / CS / MB) | **`formats`** — per-format playbooks |
| Stage 1 step 3 for the VE format — drafting the 3-Layer Hook | **`hooks`** — hook playbook + 12 templates |
| Closing CTAs for VE / CS / MB | **`ctas`** — CTA banks across 4 modes |
| Stage 2 step 5 — vetting + sourcing inline images | **`research_visuals`** — R-ladder (Wikimedia → owner → secondary → stock → escalate) + inline-media format rules |
| Stage 2 hand-off — pitching the picks, the production question, calling `create_video`, polling with `progress_hint` relay, handling 402 `credit_exhausted` / `account_expired` | **`handoff`** — A/B/C sections + observability (`progress_hint` time-based ETA) + 402 `credit_exhausted` upgrade/wait handling |

**Adding modules later — fully automatic, ZERO formatting required.** Drop a new `.md` file under `widecast/skills/video-script-writing/` and it appears in the live `available_modules[]` index returned by the entry call. The server auto-generates `title` (first H1 → first H2 → first content line → filename basename) and `summary` (first ~200 chars of meaningful content). No code change, no SKILL.md edit, no required formatting.

If you see an available module whose `title`/`summary` matches a step that this table doesn't cover yet, load it. Treat the live `available_modules[]` as the source of truth; this table is the curated default chain.

---

## Credibility (don't lose trust)

When you state a STAT/FACT/DATA — **including every number inside an invented QA/POV/CS/MB scenario** — self-rate honesty 0.0–1.0 and **be conservative**:

- 0.9–1.0 verifiable fact · 0.7–0.8 industry standard · 0.5–0.6 common-but-varies ("70% of startups fail") · ≤0.4 vague/"they say" · 0.0 misinformation.
- If you're below ~0.7, soften the claim ("often", "many") or cut it. Never write hype like "earn $10K in 24 hours guaranteed".
- For **composite practitioner figures** (CORE RULE tier 2), the score rates realism for this market — typical and defensible = 0.8+. A figure a competitor would smirk at scores low and gets fixed, not shipped.

## Anti-fluff pass

Delete: "actually, basically, really, very, just, in order to, the fact that". Every sentence should pass: *would a viewer screenshot this or learn from it?* If not, it's setup — cut it or merge it.

## Match the brand voice (all five)

Mirror the user's brand/source on six axes: **tone** (formal/casual, authoritative/humble), **POV** (consistent — usually 2nd person "you"), **style** (educational/storytelling/motivational/news/conversational), **vocabulary level**, **sentence rhythm**, existing strengths. Be **humble** — never "I'm an expert in…". Use personal **"I"** for opinions/stories or company **"We"** for brand voice — pick one and stay consistent.

**Spoken-voice spec (all five):** sentences someone can say in one breath — average 8–14 words, mixed with short punches. **Vary the music:** at least one 4–6 word sentence and one 18–25 word run somewhere in each script, never three consecutive segments in the same length band — an even rhythm reads as a metronome, not a person; a short sentence is still a full clause with a subject and a verb. **Asymmetry — real talk does not rhyme its logic:** never two consecutive segments (or clauses) built on the same syntactic frame — no chained anaphora ("Giá không hợp lý, họ đi tiếp. Nhà chưa đẹp, họ đi tiếp."), no mirrored definition pairs ("Khóa rate nghĩa là… Float nghĩa là…" — define the first, put it to work in a scenario, let the second emerge in contrast later), no question-answer echo runs. ONE parallel echo per script is the absolute cap, and only when the source itself already speaks in that rhythm — and breaking a frame NEVER means numbering it. Once per script, mid-stream, the narrator may catch and sharpen their own thought the way live speech does — a short natural pivot, never a staged gimmick, never a disfluency sound. None of these voice rules ever justifies extra words: the word budget outranks them. Contractions always (don't, you're, it's). Talk TO the viewer ("you"); rhetorical questions sparingly. Banned essay-speak: "It's important to note", "In today's world / fast-paced world", "when it comes to", "unlock", "game-changer", "dive in", "Additionally". No bullet-robot voice ("First… Second… Third…") — hand off points conversationally ("The second one's the sneaky one:"). **No em dashes in the narration**: if you feel one coming, end the sentence and start a new one (no comma-splice run-ons either — break long sentences into short spoken ones). Never use words no practitioner says out loud to a client — EN: "delve", "leverage", "seamless", "robust", "transformative", "elevate", "harness", "cutting-edge"; VI: "trong thời đại số", "hãy cùng tìm hiểu", "hãy cùng khám phá", "không thể phủ nhận", "nâng tầm", "bứt phá", "chìa khóa thành công", "trải nghiệm tuyệt vời". In languages with several "you" registers (Vietnamese: bạn / anh chị / cô chú…), pick ONE register and keep it for the entire script. **The script's language is decided by the source / target language alone:** an English source gets an English script even when the narrator's profile is written in Vietnamese or serves a Vietnamese community, and a Vietnamese source stays Vietnamese even when the profile is English — the profile colors the voice, never the language. Read each script aloud in your head; any sentence that sounds like an article gets rewritten as speech. **Face-to-face:** write for ONE listener across a table, never for "everyone watching"; the hard ask ("why pick me", "what it costs") lands late, after warmth is earned. **Performance room:** put feeling in a concrete action, never an adjective (what they did, what they stopped doing, what they couldn't do that night — not "it was stressful"); show the emotion in the beat, never announce it. Beats are added INSIDE the teaching, never instead of it — an informational script keeps every lever and number. **Spoken connectives (1–3 per script, never more):** two or three times, let a segment open or turn the way the narrator would actually say it out loud — an honesty softener, a short aside, a tag question handing the thought to the listener. Choose connectives that belong to THIS narrator — derive them from how their own community and register actually talk (their profile, their market, the source's own wording) — never a stock phrase set shared across narrators, and never the same opener twice in one script; two different narrators must never sound like they bought their tics from the same store. **Never write disfluency sounds** ("um", "uh", "ừm", "à", "ờ"): a text-to-speech voice pronounces them as full words and captions show them as typos. Never in the hook or the CTA, never to pad an empty segment.

**Beat lines (one or two per script):** a short stand-alone line of roughly five to twelve words that the narrator says TO the listener, or their own blunt take on what was just said, carrying a concrete referent from the line before. It must be a sentence a person finishes saying (subject and verb) — never a verbless slogan or a two-fragment stack ("One word. Zero coverage.", "Chậm một bước, mất căn nhà."), never a bare feeling label or validation, never a restatement or a moral. A quotable line is FOUND in plain speech, never manufactured — no credential wind-up plus colon plus polished maxim ("...bao nhiêu năm, nên tôi nói thật: giấy tờ cãi thắng, còn cái miệng thì không"); if none arises naturally, the script simply doesn't have one. **One ask per CTA** (never comment-AND-message, no sales tail); on health/money/tax/immigration/legal, never ask viewers to post their own situation publicly — a general question or yes/no, specifics by private message. **Never speak the playbook's own labels or explainer scaffolding as lines** ("here's the because", "here's where I stand", "picture this", "most people think… the truth is", "đây là N điều…", "nhiều người tưởng…", "sự thật là…"); never a line pointing at the script's own structure ("the papers I mentioned at the start", "như tôi nói ở câu đầu") — pay off an open loop by asking the question out loud and answering it, or by simply delivering the thing, never by narrating the callback; hand each next point over with a reaction to the previous one, never a number or label; no segment over ~25 words. A self-naming narrator ("Linh") uses that name as their only first person, and the viewer keeps one address throughout. A scene never re-tells the hook; a point, red flag or rule appears once. Any figure in the hook is the exact figure the body pays off. A spoken hypothetical lives in at most two segments and never gets an aftermath segment (no escalation chains, no image-fragment cap like "Đứng giữa phố lạ, tay không."); the segment right after it returns to teaching, mechanism, or the narrator's own take, never a comment on the scenario just told; a beat line is a full spoken clause aimed at the listener, never a narrated punchline painting the scenario. A promised count ("8 things to prepare") delivers exactly N countable items OF THE KIND PROMISED — concrete actions/documents, never problems padding the count. **Rhythm:** never two fact/stat lines back-to-back — after every fact comes what it means for THIS viewer, or their reaction, in the narrator's voice (a run of facts is an explainer, not a conversation). A checklist question aimed at the viewer ("have you counted…?", "anh chị đã tính đủ… chưa?") is not a hook unless it is the client's own quoted question (QA) or names a concrete stake. "I" is always the narrator — never slip into the viewer's first person. **Register from the source:** if the narrator's own writing calls themselves by name or uses a particular address for the viewer, keep it — that is their voice.

**EMOTION = stakes made concrete.** Name what it costs (money, time, sleep, embarrassment) and show the moment it bites (at claim time, at closing, at tax season). One vivid concrete detail beats three adjectives. Each format runs its own arc (per-format arcs in `formats.md`): VE curiosity→aha→confidence · QA worry→relief · POV tension→empathy→way-out · CS context→tension→turn→result · MB indignation→revelation→empowerment.

**THE NARRATOR'S OWN EXPERIENCE IS FIRST-CLASS EVIDENCE — and it is NOT a client case.** When the source or profile carries what the narrator personally went through, believes, or tells their own family, say it in first person in ANY format: it beats a mechanism for trust because only they can say it. Use only what the source/profile gives — never invent biography. On an informational topic it is texture, not the spine (every mechanism and number stays); profile facts are woven in as lived texture, never recited as a credential blurb. **PERSONAL PIECE:** when the source is the narrator speaking about themselves (intro, why-choose-me, their journey, their stance), the spine is their own story and stance; do NOT pad it with definitions, mechanisms or numbers the source doesn't contain; keep its self-reference and signature phrases; its hook opens on the narrator's sharpest lived moment or the viewer's own fear; its substance is what the narrator concretely does differently, said plainly. No FACT/STAT segment in a personal piece unless the number is in the source (the insider bar is met by the narrator's own practice detail); keep one or two of the source's signature sentences where they answer something — never stacked back-to-back; every specific about the narrator traces to the source or profile — no generalizations dressed as fact ("most plans cover…", "most of my patients are…"), no invented sensory dressing on a remembered scene.

**CLIENT-CASE SCENES LIVE IN CS ONLY.** A composite client case is the heart of the CS format and belongs nowhere else — a user posting many videos cannot open the same "my client" scene in every one. Every other format lands its stakes on the viewer instead — and the mini-scenario ("Say you…" / "Giả sử…") is a TOOL for that, not a quota. Use ONE only when the stakes stay abstract without staging — a mechanism the viewer can't yet see themselves inside, a cost that only bites once made concrete: 1–2 segments, present tense, a concrete number, the second it bites. SKIP it when the viewer already lives inside the topic (news that concerns them directly, a change hitting their own case, a simple everyday decision) — speak to their real situation ("your renewal", "your interview date") and let the stakes land there; a staged hypothetical on a self-evident topic reads fake and mechanical, and a channel whose every video opens one sounds like a machine. Most scripts need zero hypotheticals, never more than one. In any case, at most a one-clause pattern observation ("I see this every week").

**NO SAG, NO SECOND ENDING.** State the setup once — never restate the myth or the problem again in different words. A segment that adds no new information and no new feeling gets cut. When the lesson lands, go straight to the CTA: one ending, no stacked moral-of-the-story lines.

## Length + pacing

Narration pace ≈ **3.14 words/second**. In Stage 1, keep **every script at ~240–280 words (≈75–95s; hard cap 300)** — the short-form retention sweet spot, and short enough to compare five at a glance. Exception, not a second target: when the idea promises a numbered list of 6+ points (or a required arc beat would be amputated), extend up to **~360 words (≈120s absolute ceiling)** — a promised count is a contract ("8 things" = all 8 delivered; dropping promised points to fit is a worse failure than running long). But extension is earned by density, never padding: a script that can land in 90s must land in 90s. And when a script runs over, cut a WHOLE idea — never squeeze clauses into written shorthand no mouth produces ("Lịch xếp lại rơi tháng nào cũng vậy"); every surviving sentence must still read as one breath of speech. Before writing a promised list, do the division: about 220 words (budget minus hook and CTA) spread over N items sets each item's size — a 4-item list gets ~55-word items, a 5-item list ~44 — and hold every item to that number instead of discovering at the end that the script ran 90 words over. If, after picking, the user wants a longer version (~2–3 min / ~600–800 words), and it exceeds the `source="text"` 500-word cap, hand WideCast a brief via `source="idea"` (5–1000 words) and let the engine expand it.

> **WideCast API note:** `source="text"` accepts **80–500 words** (used verbatim). A short script (~150–300w) is the sweet spot. For a >500-word piece, either tighten it, or use `source="idea"` (5–1000 words).

---

## Pre-flight checklist (run before you deliver)

**Stage 1 (the scripts):**

- [ ] Mined 5–8 points with drive labels BEFORE writing; hook = auction winner as one concrete line (verbatim source numbers only); spine lands ~60–70%; each script self-judged against the eight killers (Step 0.5).
- [ ] Step 0.6 guardrails passed per script: every promised deliverable has its own beat with real content (no filler "exit", no promise-three-deliver-four); every specific traces to source / profile / signalled own practice (no invented illustrative numbers, predictions, superlatives, unsourced consequences, scope, brands, competitor jabs); second segment delivers rather than reacting to the hook; no reused sample wordings, no stance prefaces, no reveal signposts, no ordinal labels, myth opener only in MB and once; ONE self-word, ONE contrast, no "lúc nãy / as I mentioned"; each format code honoured as a spine (POV in second person present; client scenes only in CS).
- [ ] Every fitting format present (default all five VE/QA/POV/CS/MB; min 1), each under its coded heading; any skipped format shows a one-line fit-based reason instead of a script (never skipped for effort).
- [ ] Each script carries the SAME single idea; the frame differs, the topic doesn't.
- [ ] Each opens by its format's rule (VE hook / QA question / POV "POV:" / CS in-medias-res / MB myth-negation).
- [ ] Every number in every invented scenario is peer-defensible (tier 1 researched ≥0.7; tier 2 composite true-to-context) AND the internal math is consistent; frames are signalled as illustrative, never masquerading as a documented real case; no figure attributed to a nonexistent source; no guaranteed outcomes.
- [ ] Narrator persona locked & used (name / business / services); no "ask a professional" for what the narrator sells; every CTA routes value back to the narrator or their channel.
- [ ] Each ~240–280 words (cap 300; up to 360 ONLY when a promised 6+ count demands it — then every promised point is delivered); written for the ear (one-breath sentences, contractions, no essay-speak, no em dashes, one pronoun register); one idea per sentence; setup stated once, one ending only.
- [ ] 7-test self-check passed per script: proud · spoken/face-to-face · safe · emotion · owner · budget · peer (≥1 insider detail).
- [ ] Client-story scene only in CS; stakes land on the viewer in every format — directly on their real situation, or via at most ONE mini-scenario used only when the topic needs staging (zero is the norm on self-evident topics) + at most one pattern-level clause.
- [ ] Face-to-face: every line sayable to ONE person across a table; 1–2 beat lines from this script's own moment; hard ask after warmth. Personal piece: narrator's own story is the spine, nothing invented, substance = what they do differently.
- [ ] `### Research` bullets shown; closing line invites a pick by code.
- [ ] **Presentation mode declared** (`HTML-ARTIFACT` or `MARKDOWN`) per `method.md` step 4b. If the host can render interactive HTML artifacts, the versions were delivered as the editable + Copy-button artifact — NOT plain markdown.
- [ ] No image inlining yet (that's Stage 2).

**Stage 2 (the picked script):**

- [ ] Word count ≤500 if `source="text"`; one CTA, specific + actionable.
- [ ] **Vetting mode was declared out loud** (`VISION` or `URL-AUTHORITY`) before sourcing per `method.md` step 5; if the host can view images, the mode is VISION.
- [ ] **Image budget honoured: 1–3 inline images, at least one, and no two consecutive scenes both carry an image.** All other scenes left to auto-B-roll.
- [ ] (VISION) Every inline image went through all 4 states: SOURCED → DOWNLOADED → VIEWED → SHOWN-LOCAL. None inlined on caption/source alone.
- [ ] (VISION) The **local saved file** of every inline image was shown to the user — NOT the online URL.
- [ ] (URL-AUTHORITY only) Each inline URL came from a real source and passes the authority-match test in `research_visuals.md`.
- [ ] Inline media URLs are real (from `web_fetch` / search / user / a known-stable pattern, or `widecast_upload_asset` / `widecast_create_image`) — never fabricated; `.jpg`/`.jpeg`/`.png` (or allowed video ext) only.
- [ ] Any `widecast_create_image` spend (1 credit/image) was a genuine last resort and was disclosed to the user.
- [ ] `### Visual assets` / `### Backup image pool` / `### Production` sections present; credit estimate + balance shown; production question asked.
- [ ] When calling `widecast_create_video`, the two MCP-layer dialog gates are set correctly: `script_approved: true` (only after Stage 2 Step B the user saw the picked script + production sections AND picked a mode) AND `production_mode` ∈ {`faceless`, `face_clone`, `teleprompter`} (the user's EXPLICIT pick, never inferred from a prior video). Full call shape in the `handoff` module.

## Output format

Deliver the **clean spoken narration** for each of the five formats (Stage 1), under their coded headings. In Stage 2, deliver the picked script with inline media + the production sections. If the user is technical or asks, also show the segment breakdown (HOOK / MAIN_POINT / … / CTA). Don't include camera directions unless requested — WideCast generates the visuals.

---

## next_action

**Right now → load `method` (the full 8-step workflow) AND `formats` (per-format playbooks).** Then start Stage 1 step 1: lock the audience + the angle, research the facts, write every fitting format. Reach hook drafting → load `hooks`. Reach CTA → load `ctas`. Reach Stage 2 step 5 → load `research_visuals`. Reach hand-off → load `handoff`.
